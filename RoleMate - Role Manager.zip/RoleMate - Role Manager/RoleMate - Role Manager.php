<?php
/*    
Plugin Name: RoleMate - Role Manager    
Description: A lightweight plugin for digital product downloads with key verification.    
Version: 1.1    
Author: RustcoreX06    
Author URI: https://instagram.com/rustcorex06    
License: GPL2    
*/    

if (!defined('ABSPATH')) exit;

function rrm_check_for_updates() {
    $plugin_data = get_plugin_data(__FILE__);
    $current_version = $plugin_data['Version'];

    // URL where the update.json is stored
    $update_url = "https://github.com/deathsukiiqk/Updates/blob/main/update.json";

    // Fetch update details
    $response = wp_remote_get($update_url);

    if (is_wp_error($response)) {
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $update_data = json_decode($body, true);

    if (!$update_data || !isset($update_data['new_version'])) {
        return;
    }

    $new_version = $update_data['new_version'];

    if (version_compare($current_version, $new_version, '<')) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>RoleMate Plugin Update Available!</strong><br>';
        echo 'A new version (' . esc_html($new_version) . ') is available. ';
        echo '<a href="' . esc_url($update_data['download_url']) . '" target="_blank">Download here</a></p>';
        echo '<p><strong>Changelog:</strong> ' . esc_html($update_data['changelog']) . '</p>';
        echo '</div>';
    }
}

// Show update message in the WordPress admin dashboard
add_action('admin_notices', 'rrm_check_for_updates');

// Create database table on activation    
function rrm_create_table() {    
    global $wpdb;    
    $table_name = $wpdb->prefix . 'rrm_products';    
    $charset_collate = $wpdb->get_charset_collate();    
    
    $sql = "CREATE TABLE $table_name (    
        id INT AUTO_INCREMENT PRIMARY KEY,    
        name VARCHAR(255) NOT NULL,    
        description TEXT NOT NULL,    
        poster VARCHAR(255) NOT NULL,    
        file_url VARCHAR(255) NOT NULL,    
        price DECIMAL(10,2) NOT NULL,    
        product_key VARCHAR(255) NOT NULL    
    ) $charset_collate;";    
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');    
    dbDelta($sql);    
}    
register_activation_hook(__FILE__, 'rrm_create_table');    

// Admin Menu    
function rrm_admin_menu() {    
    add_menu_page('RoleMate', 'RoleMate', 'manage_options', 'rrm_admin', 'rrm_admin_page');    
}    
add_action('admin_menu', 'rrm_admin_menu');    

// Admin Page Content with Edit & Pagination    
function rrm_admin_page() {    
    global $wpdb;    
    $table_name = $wpdb->prefix . 'rrm_products';    
    
    if (isset($_POST['rrm_add_product']) && check_admin_referer('rrm_nonce_action', 'rrm_nonce')) {    
        $data = [
            'name' => sanitize_text_field($_POST['name']),    
            'description' => sanitize_textarea_field($_POST['description']),    
            'poster' => esc_url($_POST['poster']),    
            'file_url' => esc_url($_POST['file_url']),    
            'price' => floatval($_POST['price']),    
            'product_key' => sanitize_text_field($_POST['product_key'])  // No password hashing
        ];
        
        if (!empty($_POST['edit_id'])) {    
            $wpdb->update($table_name, $data, ['id' => intval($_POST['edit_id'])]);    
        } else {    
            $wpdb->insert($table_name, $data);    
        }    
    }    

    if (isset($_GET['delete']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'rrm_delete_nonce')) {    
        $wpdb->delete($table_name, ['id' => intval($_GET['delete'])]);    
    }    
    
    $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;    
    $limit = 10;    
    $offset = ($page - 1) * $limit;    
    $products = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name LIMIT %d OFFSET %d", $limit, $offset));    
    $total_products = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");    
    $total_pages = ceil($total_products / $limit);    
    
    echo '<div class="wrap"><h2>RoleMate - Role Manager</h2>';    
    echo '<form method="post">';    
    wp_nonce_field('rrm_nonce_action', 'rrm_nonce');    
    echo '<input type="hidden" name="edit_id" id="edit_id">';    
    echo '<input type="text" name="name" id="name" placeholder="Enter Product Name" required>';    
    echo '<textarea name="description" id="description" placeholder="Enter Description" required></textarea>';    
    echo '<input type="url" name="poster" id="poster" placeholder="Enter Poster URL" required>';    
    echo '<input type="url" name="file_url" id="file_url" placeholder="Enter File URL" required>';    
    echo '<input type="number" step="0.01" name="price" id="price" placeholder="Enter Price (0 for free)" required>';    
    echo '<input type="text" name="product_key" id="product_key" placeholder="Enter Product Key (if paid)" required>';    
    echo '<input type="submit" name="rrm_add_product" value="Save Product">';    
    echo '</form>';    
    
    echo '<table class="widefat fixed"><tr><th>Poster</th><th>Name</th><th>Description</th><th>Price</th><th>Key</th><th>Actions</th></tr>';    
    foreach ($products as $product) {    
        echo "<tr><td><img src='{$product->poster}' style='width:40px;'></td><td>{$product->name}</td><td>{$product->description}</td>    
        <td>{$product->price}</td><td>Hidden</td>    
        <td>    
            <a href='?page=rrm_admin&delete={$product->id}&_wpnonce=".wp_create_nonce('rrm_delete_nonce')."'>Delete</a> |    
            <button onclick='editProduct({$product->id}, \"{$product->name}\", \"{$product->description}\", \"{$product->poster}\", \"{$product->file_url}\", \"{$product->price}\")'>Edit</button>    
        </td></tr>";    
    }    
    echo '</table>';    
    
    echo '<div class="pagination">';    
    for ($i = 1; $i <= $total_pages; $i++) {    
        echo "<a href='?page=rrm_admin&paged=$i'>$i</a> ";    
    }    
    echo '</div></div>';    
}

// Shortcode to Display Products  
function rrm_display_products() {    
    global $wpdb;
    wp_cache_flush(); // Clear cache before fetching data
    $table_name = $wpdb->prefix . 'rrm_products';    
    $products = $wpdb->get_results("SELECT * FROM $table_name WHERE 1=1 ORDER BY id DESC", OBJECT);  // The latest products always display on top

    ob_start();    
    ?>
    <input type="text" id="product-search" placeholder="Search products..." style="width: 100%; padding: 10px; margin-bottom: 10px;">

    <div class="rrm-products-container">
        <?php foreach ($products as $product) { ?>    
            <div class="rrm-product" data-name="<?php echo esc_attr(strtolower($product->name)); ?>" style="display: flex; justify-content: center; align-items: center; margin: 10px;">    
                <div class="rrm-product-card" style="width: 300px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; text-align: left; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">    
                    <img src="<?php echo esc_url($product->poster); ?>" class="rrm-product-img" style="width: 100%; display: block; margin: 0 auto; border-radius: 8px;">    
                    <h3 class="product-title" style="font-size: 18px; margin-top: 15px;"><?php echo esc_html($product->name); ?></h3>    
                    <p style="font-size: 14px; color: #555;"><?php echo esc_html($product->description); ?></p>    
                    <p style="font-size: 16px; color: #000;">Price: <?php echo ($product->price == 0 ? 'Free' : '$' . esc_html($product->price)); ?></p>

                    <?php if ($product->price != 0) { ?>    
                        <input type="text" class="product-key-input" placeholder="Enter product key" required style="margin-top: 10px;">    
                    <?php } ?>    

                    <button class="download-btn" data-key="<?php echo esc_attr($product->product_key); ?>" data-file="<?php echo esc_url($product->file_url); ?>" data-price="<?php echo esc_attr($product->price); ?>" style="display: block; width: 100%; margin-top: 15px;">
                        Download
                    </button>
                </div>
            </div>    
        <?php } ?>    
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Search Filter
            document.getElementById("product-search").addEventListener("input", function () {
                let query = this.value.toLowerCase();
                document.querySelectorAll(".rrm-product").forEach(product => {
                    let name = product.dataset.name;
                    product.style.display = name.includes(query) ? "flex" : "none";
                });
            });

            // Download Button Logic
            document.querySelectorAll(".download-btn").forEach(button => {
                button.addEventListener("click", function () {
                    let productKey = this.dataset.key;
                    let fileUrl = this.dataset.file;
                    let price = this.dataset.price;
                    let inputField = this.previousElementSibling;

                    // Free product, no key required
                    if (price == 0) {
                        window.location.href = fileUrl;
                        return;
                    }

                    // Paid product, validate key
                    if (productKey !== "" && inputField) { 
                        let userKey = inputField.value.trim();
                        if (userKey !== productKey) {
                            alert("Invalid product key. Please enter the correct key.");
                            return;
                        }
                    }

                    window.location.href = fileUrl;
                });
            });
        });
    </script>

    <?php
    return ob_get_clean();    
}    
add_shortcode('rrm_products', 'rrm_display_products');

// JavaScript for Editing
add_action('admin_footer', function () {    
    echo "<script>    
    function editProduct(id, name, description, poster, file_url, price) {    
        document.getElementById('edit_id').value = id;    
        document.getElementById('name').value = name;    
        document.getElementById('description').value = description;    
        document.getElementById('poster').value = poster;    
        document.getElementById('file_url').value = file_url;    
        document.getElementById('price').value = price;    
    }    
    </script>";    
});